<?php
require_once("connect-db.php");


class make_data extends db_connection {
	
	
	function __construct($action) {
		
		$fill_tbl_sql = "SELECT * FROM task ORDER BY runid DESC";
		if ($action == "fill_tbl"){
			$this->load_json($fill_tbl_sql);
		}
		else if ($action == "load_task"){
			$runid = $_POST["task_id"];
			$fill_task_sql = "SELECT * FROM task WHERE runid = '{$runid}' LIMIT 1";
			$this->load_json($fill_task_sql);
		}
		
		
        else if ($action == "save_new"){
		  $tasktxt = $_POST["task_txt"];
		  $taskname = $_POST["task-name"];
		  $this->exex("INSERT INTO task (taskname, tasktxt) VALUES ('{$taskname}', '{$tasktxt}')");	
		  $this->load_json($fill_tbl_sql);
			
		}
		
		 else if ($action == "update"){
			
		  $tasktxt = $_POST["task_txt"];
		  $taskname = $_POST["task-name"];
		  $runid = $_POST["runid"];	
		  $completed = $_POST["completed"];
		  $msql = "UPDATE task SET taskname = '{$taskname}',tasktxt = '{$tasktxt}',completed = {$completed} WHERE runid = '{$runid}'";
		  $this->exex($msql);	
		  $this->load_json($fill_tbl_sql);
			
		}
		
		 else if ($action == "delete"){
			
		  $runid = $_POST["runid"];	
		  $msql = "DELETE FROM task WHERE runid = '{$runid}'";
		  $this->exex($msql);	
		  $this->load_json($fill_tbl_sql);
			
		}
		
		
		
    }
	
	function load_json($sql){
		$myArray = array();
		$this->get_connect();
		if ($result = $this->mysqli->query($sql)) {

			while($row = $result->fetch_array(MYSQL_ASSOC)) {
					$myArray[] = $row;
			}
			
			mysqli_close($this->mysqli);	
			echo json_encode($myArray);
		}
		
		
		 
	}
	
	
	function exex($sql){
			$this->get_connect();
			$msg_err = "";
			$this->mysqli->query($sql);
			$err = $this->mysqli->errno;
			mysqli_close($this->mysqli);
			
	}
	
}

if (isset($_POST["action"])){
	$d = new make_data($_POST["action"]);
}
