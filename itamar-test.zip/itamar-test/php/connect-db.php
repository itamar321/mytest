<?php
class db_connection {
	protected $mysqli;
	
	protected function get_connect(){
		
		$this->mysqli = new mysqli("localhost", "root", "", "task_db");  // local
			
			if ($this->mysqli->connect_errno) {
				echo $this->error;
				return;
			}
			
		mysqli_set_charset($this->mysqli, "utf8");
		
		
	}
}


