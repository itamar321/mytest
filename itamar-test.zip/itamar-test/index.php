<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">

  <title>itamar test</title>

  <script src="jquery/jquery-3.4.1.min.js"></script>
  <link rel="stylesheet" href="css/styles.css?v=1.0">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="javascript/js.js"></script>	
  
</head>

<body>
	
	<div class="section-limit">
	
		<div class="main-panel">
			<div class="row">
			
				<div class="col-md-4">
					<div>
						<div class="counter">
							Total tasks
							
							<div class="number total">	
							</div>	
							
						</div>
						
					</div>
				</div>
				
				<div class="col-md-4">
					<div>
						<div class="counter">
							Task completed
							
							<div class="number completed">
							</div>	
							
						</div>
						
					</div>
				</div>
				
				<div class="col-md-4">
					<div>
						<div class="counter">
							Task Remeaninig
							
							<div class="number rem">
						
							</div>	
							
						</div>
						
					</div>
				</div>
				
			 </div>
		 </div>
		 
		 <!-- start table -->
		 
		
		 <div class="table-container">
		  <table class="table">
			<thead>
			  <tr>
				<th>#</th>
				<th>Task name</th>
				<th>Date</th>
				<th><button type="button" class="btn btn-primary open-modal" id="add-new" >Add New Task +</button></th>
			  </tr>
			</thead>
			<tbody>
			 <!-- fill content with json -->
			</tbody>
		  </table>
		</div>
		
		 
		 <!-- end table -->
		 
	
	</div>
	
	<!-- start pop up modal -->
	
	<div id="taskModal" class="modal fade" role="dialog">
		<div class="modal-dialog" >
		
			<!-- Modal content-->
		<div class="modal-content" >
		  <div class="modal-header">
			<h4 class="modal-title">Task manager <div class="sub-title" data-exist="off"> </div></h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>
		  <div class="modal-body">
			
			
			<div>
				Task name
				<br/>
				<input type="text" id="task-name" />
			</div>
			
			<div>
				Some text
				<br/>
				<textarea rows="4" cols="50" id="task-txt"></textarea>
			</div>
			
			<div id="status">
				Status
				<br/>
				<input type="checkbox" id="completed-task" /> Completed task
			</div>
			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-danger" id="delete">Delete</button>
			<button type="button" class="btn btn-primary" id="update" >Update</button>
			<button type="button" class="btn btn-primary" id="save" >Save</button>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>
		
		</div>
		
		<input type="hidden" id="task-id" value="-1" />
	</div>
	
	<!-- end popup modal -->
	
	
	
</body>
</html>