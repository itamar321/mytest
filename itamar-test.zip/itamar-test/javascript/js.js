
$( document ).ready(function() {
	

	$.post("php/php-script.php", {"action": "fill_tbl"}, function(result){
			try {
				fillSet(result);
			} catch (e){
				var output = "";
				output += "<h2>Fix your data base and try again</h2>";
				output += "data base setting at php/<b>connect-dp.php</b>";
				output += "<br/>";
				output += "import the tables from <b>task_db.sql</b>";
				$(".table-container").html(output);
				
			}
			
	
	});
	

	$('body').on('click', '.open-modal', function() {
		
		var callerId = $(this).attr("id");
		resetModal();
		
		if (callerId == "add-new"){
			setAdd();
		}
		
		if (callerId.split("-")[0] == "task"){
			setView();
						
			var taskId = callerId.split("-")[1];
			$.post("php/php-script.php", {"action": "load_task","task_id":taskId}, function(result){	
				var modalData = JSON.parse(result);
				$("#task-name").val(modalData[0].taskname);
				$("#task-txt").val(modalData[0].tasktxt);
					
				if (modalData[0].completed == 0){
					$('#completed-task')[0].checked = false;
				} else {
					$('#completed-task')[0].checked = true;
				}
				
				$("#task-id").val(taskId);
			});
			
		}
		
		$('#taskModal').modal('show');
	});
		
		
	$('body').on('click', '#taskModal #save', function() {
		$.post("php/php-script.php", {"action": "save_new","task-name":$("#task-name").val(),"task_txt":$("#task-txt").val()}, function(result){
			fillSet(result);
			resetModal();
		});
	});
	
	$('body').on('click', '#taskModal #update', function() {
		
		$.post("php/php-script.php", {"action": "update","task-name":$("#task-name").val(),"task_txt":$("#task-txt").val(),"runid":$("#task-id").val(),"completed":$('#completed-task')[0].checked}, function(result){
			refreshScreeen(result);
		});
	});

	$('body').on('click', '#taskModal #delete', function() {
		$.post("php/php-script.php", {"action": "delete","runid":$("#task-id").val()}, function(result){
			refreshScreeen(result);
		});
	});	
	
	
});

function refreshScreeen(result){
	fillSet(result);
	resetModal();	
}

function resetModal(){
	$("#task-name").val("");
	$("#task-txt").val("");
	$("#taskModal #status").hide();
	$("#taskModal #save").hide();
	$("#taskModal #update").hide();
	$("#taskModal #delete").hide();
	$("#taskModal #completed-task")[0].checked = false;
	$("#taskModal .sub-title").html("");
}

function setAdd(){
	$("#taskModal .sub-title").html("add new");
	$("#taskModal #save").show();
	$("#taskModal #status").hide();
}
function setView(){
	$("#taskModal #status").show();
	$("#taskModal #update").show();
	$("#taskModal #delete").show();
}


function fillSet(json_obj){
	var output = "";
	json_obj = JSON.parse(json_obj);
	
	var total = json_obj.length;
	var completed = 0;
	
	for (i=0;i< json_obj.length;i++){
		
		output += "<tr>";
		output += "<td>" + i + "</td>";
		output += "<td>" + json_obj[i].taskname +"</td>";
		output += "<td>" + json_obj[i].intime + "</td>";
		output += "<td>";
		output += "<button type='button' class='btn btn-info open-modal' id='task-" + json_obj[i].runid + "' >View task</button>";
		output += "</td>";
		output += "</tr>";
		
		if (json_obj[i].completed == 1){
			completed++;
		}
		
	}
	
	$(".main-panel .number.total").html(json_obj.length);
	$(".main-panel .number.completed").html(completed);
	$(".main-panel .number.rem").html(json_obj.length - completed);
	
	$(".table-container .table tbody").html(output);
	$('#taskModal').modal('hide');
	
}